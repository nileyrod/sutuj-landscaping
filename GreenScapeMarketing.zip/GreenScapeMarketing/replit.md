# Sutuj Landscaping Website

## Overview
A modern, responsive single-page marketing website for Sutuj Landscaping, a local landscaping and hardscaping company serving Midlothian, Chesterfield, and nearby areas in Virginia.

## Project Structure
```
/
├── index.html          # Complete single-page website (HTML, CSS, JS)
├── replit.md           # Project documentation
└── attached_assets/    # Project images and reference materials
    ├── sutuj img 1_*.webp  # Fire pit & patio
    ├── sutuj img 2_*.webp  # Patio & stone seating wall
    ├── sutuj img 3_*.webp  # Backyard patio
    ├── sutuj img 4_*.webp  # Front yard landscaping
    ├── sutuj img 5_*.webp  # Walkway & stone steps
    └── sutuj img 6_*.webp  # Stone pathway
```

## Technical Stack
- **HTML5**: Semantic markup with accessibility features
- **CSS3**: Custom properties, Flexbox, Grid, responsive design
- **Vanilla JavaScript**: Form validation, mobile navigation, scroll behaviors
- **Google Fonts**: Poppins font family

## Features
1. **Sticky Navigation**: Desktop and mobile (hamburger menu) support
2. **Hero Section**: Dual CTA buttons, business info, hero image showcasing front yard work
3. **Services Section**: 6-card responsive grid showcasing service offerings
4. **Projects Gallery**: 6-tile grid with real project photos and hover overlays
5. **About Section**: Company history, trust indicators, two-column layout with team photo
6. **Reviews Section**: 3 testimonial cards with star ratings
7. **Contact Form**: Client-side validation, success message display
8. **Hours Strip**: Business hours and service area info
9. **Footer**: Contact info, social links, copyright
10. **Back to Top Button**: Appears on scroll, smooth scroll behavior

## Business Information
- **Business**: Sutuj Landscaping
- **Phone**: (804) 301-9437
- **Email**: luisutuj@gmail.com
- **Location**: Chesterfield, VA
- **Service Area**: Midlothian, Chesterfield, and nearby areas
- **Hours**: Sun-Thu 7AM-10PM, Fri 7AM-5PM, Sat Closed

## Color Palette
- Deep Green: #1a5336
- Light Green: #4a9d6e
- Accent Green: #6bbf8a
- White: #ffffff
- Charcoal: #2d3436

## Customization Notes
To customize this site:
1. Replace placeholder images in hero and about sections with actual photos
2. Replace project gallery placeholders with real project photos
3. Update social media links (Facebook, Google Business) with actual URLs
4. Connect contact form to backend service for actual form submissions
5. Add real Google Reviews integration if desired

## Running the Project
The website is served via Python's built-in HTTP server on port 5000.

## Recent Changes
- November 30, 2025: Updated header logo from leaf emoji to modern tree silhouette icon
- November 30, 2025: Replaced emoji icons with professional SVG icons in Services section
- November 30, 2025: Added team/customer interaction photo to About section
- November 30, 2025: Added 6 real project photos to Featured Projects gallery
- November 30, 2025: Initial website creation with all sections implemented
